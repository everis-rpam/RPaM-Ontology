
sh validate.sh ../xsd/maindoc/UBL-Invoice-2.1.xsd InvoiceExt.xml
sh validate.sh ../xsd/maindoc/UBL-Invoice-2.1.xsd InvoiceExtBad.xml
sh validate.sh ../xsd/mydoc/MyReturnAuthorizationRequest.xsd MyRARequest.xml
sh validate.sh ../xsd/mydoc/MyReturnAuthorizationRequest.xsd MyRARequestBad.xml
sh validate.sh ../xsd/mydoc/MyReturnAuthorizationResponse.xsd MyRAResponse.xml
sh validate.sh ../xsd/mydoc/MyReturnAuthorizationResponse.xsd MyRAResponseBad.xml
sh validate.sh ../xsdrt/maindoc/UBL-Invoice-2.1.xsd InvoiceExt.xml
sh validate.sh ../xsdrt/maindoc/UBL-Invoice-2.1.xsd InvoiceExtBad.xml
sh validate.sh ../xsdrt/mydoc/MyReturnAuthorizationRequest.xsd MyRARequest.xml
sh validate.sh ../xsdrt/mydoc/MyReturnAuthorizationRequest.xsd MyRARequestBad.xml
sh validate.sh ../xsdrt/mydoc/MyReturnAuthorizationResponse.xsd MyRAResponse.xml
sh validate.sh ../xsdrt/mydoc/MyReturnAuthorizationResponse.xsd MyRAResponseBad.xml
sh validatejson.sh ../json-schema/maindoc/UBL-Invoice-2.1.json Invoice.json
sh validatejson.sh ../json-schema/maindoc/UBL-Invoice-2.1.json InvoiceBad.json
